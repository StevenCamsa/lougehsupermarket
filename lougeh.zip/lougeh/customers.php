<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <title>Lou Geh Supermarket </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <link rel="shortcut icon" href="img/favicon.ico">

</head>

<body>
<!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">
                <span>LouGeh Supermarket</span></a>
        </div>
    </div>
    <!-- topbar ends -->
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <?php 
            include('includes/sidemenu.php');
        ?>
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div class="col-md-10">
                <ul class="breadcrumb">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="customers.php">Customers</a>
                    </li>
                </ul>

            </div>
            <div class="col-md-2">
                <!-- <button href="newtransaction.php" type="button" data-toggle="modal" data-target="#newTransaction" class="btn btn-primary col-md-12" title="New Transaction" name="new"><i class="glyphicon glyphicon-plus"></i> New Transaction</button> -->
                <a href="newcustomer.php" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i> Edit</a>
            </div>
            <br>
<div class="row">
    <div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-info-sign"></i> Customers</h2>
                <!-- <div class="box-icon">
                    <a href="newtransaction.php" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-plus"></i></a>
                </div> -->
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">
                        <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
                        <thead>
                        <tr>
                            <th width="15">Customer ID</th>
                            <th>Customer name</th>
                            <th>Customer Address</th>
                            <th>Contact Number</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                                include('includes/config.php');

                                function convert($toConvert){
                                    return number_format($toConvert, 2);
                                }

                                $query = mysqli_query($conn, "SELECT * FROM customers");
                                $numrows = mysqli_num_rows($query);
                                if ($numrows != 0) {
                                
                                    while ($row = mysqli_fetch_array($query)) {
                                        $customer_id = $row['customer_id'];
                                        $customer_name = $row['customer_firstname']." ".$row['customer_mi'].". ".$row['customer_lastname'];
                                        $address = $row['customer_address'];
                                        $contact = $row['customer_contact_number'];

                                        echo "<tr>";
                                        echo "<td>$customer_id</td>";
                                        echo "<td>$customer_name</td>";
                                        echo "<td>$address</td>";
                                        echo "<td>$contact</td>";
                                        echo "</tr>";

                                    }
                                }
                                else{
                            ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php } ?>

                        </tbody>
                        </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div><!--/.fluid-container-->

<!-- external javascript -->



<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>
<?php
    include('modals.php');
?>

</body>
</html>
