<?php
session_start();
include('includes/config.php');

$type = $_REQUEST['type'];
$id = $_REQUEST['id'];

$_SESSION['id'] = $id;
$_SESSION['type'] = $type;

header('location:newtransaction.php');


?>