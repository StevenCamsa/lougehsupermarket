<link href="css/charisma-app.css" rel="stylesheet">
<link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
<link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
<link href='css/jquery.noty.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Select Item</h4>
</div>
<div class="modal-body">
  <form name="dept" method="post">
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
        <th>Barcode</th>
        <th>Description</th>
        <th>Instock</th>
        <th>Cost/unit</th>
        <th width="5">Select</th>
    </tr>
    </thead>
    <tbody>
   
        <?php
          include('includes/config.php');

          function convert($toConvert){
              return number_format($toConvert, 2);
          }

          $query = mysqli_query($conn, "SELECT * FROM items");
          $numrows = mysqli_num_rows($query);

          if ($numrows != 0) {
              while ($row = mysqli_fetch_array($query)) {
                 
                  $barcode = $row['barcode'];
                  $description = $row['product_description'];
                  $quantity = $row['quantity'];
                  $costperunit = convert($row['cost_per_unit']);
                
                  echo "<tr>";
                  echo "<td>$barcode</td>";
                  echo "<td>$description</td>";
                  echo "<td>$quantity</td>";
                  echo "<td>₱ $costperunit</td>";
                  echo "<td>
                    <a href='selectitemfunction.php?curbar=$barcode' class='btn btn-primary btn-sm'><i class='glyphicon glyphicon-check'></i></a>
                  </td>";
                  echo "</tr>";

              }
          }
          else{
              ?>
              <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
              </tr>

              <?php
          }
      ?>
    
    </tbody>
    </table>
  </form>
</div>
      <span style="color: white">Ender</span>

<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>