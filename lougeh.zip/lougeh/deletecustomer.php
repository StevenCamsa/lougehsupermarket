<?php
	include('includes/config.php');

	$cid = $_REQUEST['cid'];

	mysqli_query($conn, "DELETE FROM customers WHERE customer_id = '$cid'");
	mysqli_query($conn, "DELETE FROM sales_transaction WHERE customer_id = '$cid'");

	header("location:newcustomer.php");

?>