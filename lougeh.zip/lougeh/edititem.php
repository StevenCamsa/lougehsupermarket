<?php
    session_start();
    include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <title>Lou Geh Supermarket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <link rel="shortcut icon" href="img/favicon.ico">

</head>

<body>
<!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"> 
                <span>Lou Geh</span></a>
        </div>
    </div>
    <!-- topbar ends -->
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <?php 
            include('includes/sidemenu.php');
        ?>
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div class="col-md-12">
                <ul class="breadcrumb">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="items.php">Items</a>
                    </li>
                    <li>
                        <a href="newitem.php">New item</a>
                    </li>
                    <li>
                        <a href="edititem.php">Edit item</a>
                    </li>
                </ul>

            </div>

            <br>
           
<div class="row">
    <div class="box col-md-4">
        <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-plus"></i> New Item</h2>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">

                         <?php

                            function convert($toConvert){
                                return number_format($toConvert, 2);
                            }

                            $oldbar = $_REQUEST['obarcode'];
                            $query2 = mysqli_query($conn, "SELECT * FROM items WHERE barcode = '$oldbar'"); 
                            $row2 = mysqli_fetch_array($query2);
                            $product_description2 = $row2['product_description'];
                            $quantity2 = $row2['quantity'];
                            $cost2 = convert($row2['cost_per_unit']);

                            if (isset($_POST['save'])) {
                                

                                $barcode = $_POST['barcode'];
                                $desc = $_POST['descr'];
                                $quantity = $_POST['quantity'];
                                $costperunit = $_POST['cost'];


                                $sql = "UPDATE items SET barcode = '$barcode', product_description = '$desc', quantity = $quantity, cost_per_unit = $costperunit WHERE barcode = '$oldbar'";

                                echo $sql;

                                mysqli_query($conn, $sql);

                                echo '<meta http-equiv="refresh" content="0; URL=http://localhost/lougeh/newitem.php">';

                            }
                        ?>
                        <form method="POST">
                            <div class="col-md-12">
                                <label>Barcode:</label>
                                <input type="text" name="barcode" class="form-control" placeholder="Barcode" required="" value="<?php echo $oldbar; ?>">
                            </div>
                            <div class="col-md-12"><br>
                                <label>Item Description:</label>
                                <input type="text" name="descr" class="form-control" placeholder="Item Description" required="" value="<?php echo $product_description2; ?>">
                            </div>
                            <div class="col-md-6"><br>
                                <label>Quantity:</label>
                                <input type="number" name="quantity" id="quantity" class="form-control" min="1" placeholder="Quantity" required=""  value="<?php echo $quantity2; ?>">
                            </div>
                            <div class="col-md-6"><br>
                                <label>Cost/unit:</label>
                                <input type="number" name="cost" id="cost" class="form-control" min="0" step=".01"  placeholder="Cost per Unit" required=""  value="<?php echo $cost2; ?>">
                            </div>
                            <div class="col-md-5"><br><br>
                                <button name="save" class="btn btn-primary col-md-12"><i class="glyphicon glyphicon-plus"></i> Save Item</button>
                            </div>
                        </form>
                    </div>
                </div>
                <span style="color: white">Ender</span>
            </div>
        </div>
    </div>
    <div class="box col-md-8">
        <div class="box-inner">
            <div class="box-header well">
                <div class="col-md-10">
                    <h2><i class="glyphicon glyphicon-info-sign"></i> Items</h2>
                </div>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">
                        <table class="table table-striped table-bordered bootstrap-datatable  responsive">
                        <thead>
                        <tr>
                            <th>Barcode</th>
                            <th>Item Description</th>
                            <th width="5">Qty Available</th>
                            <th>Cost/unit</th>
                            <th width="5">Options</th>
                        </tr>
                        </thead>
                        <tbody>
                    
                            <?php
                                $query = mysqli_query($conn, "SELECT * FROM items");
                                $numrows = mysqli_num_rows($query);
                                if ($numrows != 0) {
                                    while ($row = mysqli_fetch_array($query)) {
                                       
                                        $fbarcode = $row['barcode'];
                                        $fdesc = $row['product_description'];
                                        $fquantity = $row['quantity'];
                                        $fcost = convert($row['cost_per_unit']);
                                        $message = "Remove item from the database?";

                                        echo "<tr><td>$fbarcode</td>";
                                        echo "<td>$fdesc</td>";
                                        echo "<td>$fquantity</td>";
                                        echo "<td>₱ $fcost</td>";?>
                                        <td>
                                            <a href="edititem.php?obarcode=<?php echo $fbarcode; ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></a>
                                            <a class="btn btn-danger btn-sm" onclick="confirm('Remove item from the database?')" href="deleteitem.php?ntid=<?php echo $fbarcode; ?>"><i class='glyphicon glyphicon-remove'></i></a></td>
                                        <?php
                                        echo "</tr>";

                                    }
                                }
                                else{
                                    ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>

                                    <?php
                                }
                            ?>
                
                        </tbody>
                        </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div><!--/.fluid-container-->

<!-- external javascript -->



<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>
<?php
    include('modals.php');
?>

</body>
</html>
