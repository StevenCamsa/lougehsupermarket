<?php
	include('includes/config.php');

	$cid = $_REQUEST['cid'];

	mysqli_query($conn, "DELETE FROM suppliers WHERE supplier_id = '$cid'");
	mysqli_query($conn, "DELETE FROM delivery_transaction WHERE supplier_id = '$cid'");

	header("location:newsupplier.php");

?>