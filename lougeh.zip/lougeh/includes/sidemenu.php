<!-- <div class="col-sm-2 col-lg-2">
    <div class="sidebar-nav">
        <div class="nav-canvas">
            <div class="nav-sm nav nav-stacked">

            </div>
            <ul class="nav nav-pills nav-stacked main-menu">
                <li class="nav-header">Main</li>
                <li><a class="ajax-link" href="index.php"><i class="glyphicon glyphicon-home"></i><span> Transactions</span></a>
                </li>
                <li><a class="ajax-link" href="items.php"><i class="glyphicon glyphicon-tasks"></i><span> Items</span></a>
                </li>
                <li><a class="ajax-link" href="customers.php"><i class="glyphicon glyphicon-user"></i><span> Customers</span></a>
                </li>
                <li><a class="ajax-link" href="suppliers.php"><i class="glyphicon glyphicon-plus"></i><span> Suppliers</span></a>
                </li>
            </ul>
            
        </div>
    </div>
</div> -->

   <!-- ======= Sidebar ======= -->
   <div class="col-sm-2 col-lg-2">

    <ul class="sidebar-nav" id="sidebar-nav">
     
      <li class="nav-item">
        <a class="nav-link collapsed" href="index.php">
          <i class="bi bi-receipt-cutoff"></i>
          <span>Transactions</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="items.php">
          <i class="bi bi-ui-checks"></i>
          <span>Items</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="customers.php">
          <i class="bi bi-person"></i>
          <span>Customers</span>
        </a>
      </li><!-- End F.A.Q Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="suppliers.php">
          <i class="bi bi-bag-check"></i>
          <span>Suppliers</span>
        </a>
      </li><!-- End Contact Page Nav -->
    </ul>


</div><!-- End Sidebar -->